# Cloud Infrastructure Deployment and DevOps Automation

A production-style DevOps project that takes a Python (Flask) web application from source code all the way to a live AWS EC2 server — using Docker for containerization, Git/GitHub for version control, GitHub Actions for CI, and Terraform for Infrastructure as Code.

This project was built to demonstrate real, hands-on DevOps skills: containerizing an app, automating builds through CI, provisioning cloud infrastructure with code, and deploying to a Linux server.

---

## Table of Contents

- [Project Overview](#project-overview)
- [Architecture Diagram](#architecture-diagram)
- [Folder Structure](#folder-structure)
- [Features](#features)
- [Technologies Used](#technologies-used)
- [Installation (Local Setup)](#installation-local-setup)
- [Docker Commands](#docker-commands)
- [Terraform Commands](#terraform-commands)
- [AWS Deployment Steps](#aws-deployment-steps)
- [Git Commands](#git-commands)
- [Screenshots](#screenshots)
- [Learning Outcomes](#learning-outcomes)
- [Future Enhancements](#future-enhancements)
- [License](#license)

---

## Project Overview

This project simulates a real-world DevOps workflow used by cloud engineering teams:

1. A Flask web application is developed and version-controlled with Git.
2. The application is containerized using Docker.
3. Every push to GitHub triggers a GitHub Actions CI pipeline that lints, tests, and builds the Docker image.
4. AWS infrastructure (EC2 instance + security group) is provisioned using Terraform.
5. The Docker container is deployed and run on the provisioned EC2 instance running Ubuntu Linux.

The result is a fully automated path from `git push` to a running application in the cloud.

---

## Architecture Diagram

```
 Developer Machine
      │
      │ git push
      ▼
 ┌─────────────┐        ┌───────────────────────┐
 │   GitHub    │──────► │   GitHub Actions CI    │
 │  Repository │        │  (lint, test, build)   │
 └─────────────┘        └───────────────────────┘
      │
      │ terraform apply
      ▼
 ┌───────────────────────────────────────────┐
 │                AWS Cloud                    │
 │  ┌───────────────────────────────────────┐  │
 │  │   Security Group (22, 5000 open)       │  │
 │  │   ┌─────────────────────────────────┐ │  │
 │  │   │   EC2 Instance (Ubuntu Linux)   │ │  │
 │  │   │   ┌───────────────────────────┐ │ │  │
 │  │   │   │  Docker Container         │ │ │  │
 │  │   │   │  Flask App (port 5000)    │ │ │  │
 │  │   │   └───────────────────────────┘ │ │  │
 │  │   └─────────────────────────────────┘ │  │
 │  └───────────────────────────────────────┘  │
 └───────────────────────────────────────────┘
      │
      ▼
   End User (Browser)
```

---

## Folder Structure

```
Cloud-Infrastructure-Deployment-and-DevOps-Automation/
│
├── app.py                        # Flask application
├── requirements.txt              # Python dependencies
├── Dockerfile                    # Docker build instructions
├── .dockerignore                 # Files excluded from Docker build
├── .gitignore                    # Files excluded from Git
├── README.md                     # Project documentation
├── LICENSE                       # MIT License
│
├── templates/
│   ├── index.html                # Home page
│   └── about.html                # About page
│
├── static/
│   └── style.css                 # Application styling
│
├── terraform/
│   ├── provider.tf               # AWS provider configuration
│   ├── variables.tf              # Input variables
│   ├── main.tf                   # EC2 + Security Group resources
│   ├── outputs.tf                # Terraform outputs
│   └── terraform.tfvars.example  # Example variable values
│
└── .github/
    └── workflows/
        └── ci.yml                # GitHub Actions CI pipeline
```

---

## Features

- **Home Page** — Landing page with a responsive Bootstrap UI
- **About Page** — Project and technology overview
- **Health Endpoint** (`/health`) — Returns JSON status, used for uptime/monitoring checks
- **System Info Endpoint** (`/system-info`) — Returns host, platform, and runtime details as JSON
- **Custom Error Handling** — Clean 404 and 500 error responses
- **Environment Variable Support** — App reads configuration (like `PORT` and `ENV`) from environment variables
- **Responsive UI** — Built with Bootstrap 5, works on desktop and mobile

---

## Technologies Used

| Category            | Technology        |
|---------------------|--------------------|
| Language             | Python 3.11        |
| Web Framework        | Flask               |
| Frontend             | HTML5, CSS3, Bootstrap 5 |
| Containerization      | Docker              |
| Infrastructure as Code | Terraform          |
| Cloud Provider        | AWS (EC2, Security Groups) |
| CI/CD                 | GitHub Actions      |
| Version Control        | Git & GitHub        |
| Server OS             | Ubuntu Linux (EC2)  |

---

## Installation (Local Setup)

Clone the repository and run the app locally without Docker:

```bash
# Clone the repository
git clone https://github.com/<your-username>/Cloud-Infrastructure-Deployment-and-DevOps-Automation.git
cd Cloud-Infrastructure-Deployment-and-DevOps-Automation

# Create a virtual environment
python3 -m venv venv
source venv/bin/activate      # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run the app
python app.py
```

The app will be available at `http://localhost:5000`.

---

## Docker Commands

Build and run the application inside a Docker container:

```bash
# Build the Docker image
docker build -t devops-flask-app .

# Run the container
docker run -d -p 5000:5000 --name devops-flask-app devops-flask-app

# Check running containers
docker ps

# View container logs
docker logs devops-flask-app

# Stop the container
docker stop devops-flask-app

# Remove the container
docker rm devops-flask-app
```

Visit `http://localhost:5000` to view the running application.

---

## Terraform Commands

Provision the AWS infrastructure (EC2 instance + security group):

```bash
cd terraform

# Copy the example variables file and fill in your values
cp terraform.tfvars.example terraform.tfvars

# Initialize Terraform
terraform init

# Preview the infrastructure changes
terraform plan

# Apply and create the infrastructure
terraform apply

# Destroy the infrastructure when done
terraform destroy
```

After `terraform apply` completes, Terraform will output the EC2 instance's public IP address.

---

## AWS Deployment Steps

Once the EC2 instance is running (via Terraform), SSH into it and deploy the app:

```bash
# SSH into the EC2 instance
ssh -i your-key.pem ubuntu@<EC2_PUBLIC_IP>

# Update packages
sudo apt update && sudo apt upgrade -y

# Install Docker
sudo apt install -y docker.io
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker ubuntu

# Log out and back in for group changes to apply, then:

# Clone the repository
git clone https://github.com/<your-username>/Cloud-Infrastructure-Deployment-and-DevOps-Automation.git
cd Cloud-Infrastructure-Deployment-and-DevOps-Automation

# Build the Docker image
docker build -t devops-flask-app .

# Run the container
docker run -d -p 5000:5000 --name devops-flask-app devops-flask-app

# Verify the app is running
curl http://localhost:5000/health
```

Open `http://<EC2_PUBLIC_IP>:5000` in a browser to see the live application.

---

## Git Commands

Common Git commands used throughout this project's workflow:

```bash
# Initialize a repository
git init

# Check status
git status

# Stage changes
git add .

# Commit changes
git commit -m "Add feature: description here"

# Connect to a remote repository
git remote add origin https://github.com/<your-username>/<repo-name>.git

# Push to GitHub
git push -u origin main

# Pull latest changes
git pull origin main

# Create and switch to a new branch
git checkout -b feature/new-feature
```

---

## Screenshots

> Add screenshots here after running the project locally or on AWS.

- `screenshots/home-page.png` — Home page
- `screenshots/about-page.png` — About page
- `screenshots/health-endpoint.png` — `/health` JSON response
- `screenshots/github-actions.png` — Successful CI pipeline run
- `screenshots/ec2-running.png` — Application running on EC2

---

## Learning Outcomes

Through this project, the following DevOps skills were practiced and demonstrated:

- Writing a real Flask application with multiple routes and error handling
- Containerizing an application using Docker best practices
- Writing a CI pipeline in GitHub Actions that lints, tests, and builds automatically
- Writing Infrastructure as Code with Terraform to provision AWS resources
- Managing AWS EC2 instances and security groups
- Deploying and running Docker containers on a remote Linux server
- Using Git and GitHub for version control in a professional workflow

---

## Future Enhancements

- Add automated deployment to EC2 as a final CI/CD step (continuous deployment)
- Push Docker images to Amazon ECR or Docker Hub from the pipeline
- Add unit tests with `pytest` and code coverage reporting
- Use an Application Load Balancer and Auto Scaling Group for high availability
- Add HTTPS using an SSL certificate (AWS Certificate Manager / Let's Encrypt)
- Store Terraform state remotely using an S3 backend with state locking (DynamoDB)
- Add monitoring and alerting with AWS CloudWatch

---

## License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.
